use autocomp_core::{AutoCompiler, CompileOptions, Profile, ProfileFormat, VerifyReport, Workload};
use std::io::Write;
use std::process::{Command, Stdio};
use std::fs;
use std::path::PathBuf;
use std::time::Duration;

fn main() -> Result<(), String> {
    let args: Vec<String> = std::env::args().collect();
    let command = args.get(1).map(String::as_str).unwrap_or("help");
    match command {
        "cc" | "c++" => compile(&args[2..]),
        "optimize" => auto_pgo(&args[2..]),
        "profile" => profile(&args[2..]),
        "report" => report(&args[2..]),
        "verify" => verify(&args[2..]),
        "bench" => bench(&args[2..]),
        "help" | "--help" | "-h" => {
            println!("autocomp <command> [options]\n\nCommands:\n  cc               C compiler\n  c++              C++ compiler\n  profile          collect profile\n  optimize         PGO build\n  report           optimization report (HTML)\n  bench            quick benchmark\n\nOptions:\n  -O3              enable optimization level 3\n  --instrument     emit instrumented object\n  --pgo=<file>     compile with profile (repeatable)\n  --output=<file>  output path for profile/report\n  --workload=<s>   workload label for auto PGO
  --no-run         skip running the generated demo binary
  --baseline       compare optimized result with a plain build in report
  --format=json    emit JSON report instead of HTML
  --verify         include reproducible verification in report
  --strict-verify  treat skipped verification checks as failures
  --input=<file>   workload stdin fixture path
  --strict-check   fail compilation when verification skips occur
  ");
            Ok(())
        }
        other => Err(format!("unknown command: {other}")),
    }
}

fn source_from(args: &[String]) -> Option<PathBuf> {
    args.iter().filter(|a| !a.starts_with('-')).find(|a| a.ends_with(".ac") || a.ends_with(".c") || a.ends_with(".cc") || a.ends_with(".cpp") || a.ends_with(".rs")).map(PathBuf::from)
}

fn option_value(args: &[String], name: &str) -> Option<String> {
    args.iter().find_map(|a| a.strip_prefix(name).map(str::to_string))
}

fn load_profile_inputs(args: &[String]) -> Result<Vec<(PathBuf, Profile)>, String> {
    let mut inputs = Vec::new();
    for arg in args {
        if let Some(path) = arg.strip_prefix("--pgo=") {
            let text = fs::read_to_string(path).map_err(|e| e.to_string())?;
            inputs.push((PathBuf::from(path), Profile::from_text(&text)?));
        }
    }
    Ok(inputs)
}

fn merge_profile_inputs(inputs: &[ (PathBuf, Profile) ]) -> (Option<Profile>, Option<autocomp_core::ProfileMergeReport>) {
    let mut merged = Profile::default();
    let mut report = autocomp_core::ProfileMergeReport::default();
    for (_, profile) in inputs {
        let current = merged.merge_report(profile);
        report.function_overlap += current.function_overlap;
        report.branch_overlap += current.branch_overlap;
        report.loop_overlap += current.loop_overlap;
        report.function_samples += current.function_samples;
        report.branch_samples += current.branch_samples;
        report.loop_samples += current.loop_samples;
    }
    if inputs.is_empty() {
        (None, None)
    } else {
        (Some(merged), Some(report))
    }
}

fn load_profiles(args: &[String]) -> Result<Option<Profile>, String> {
    Ok(merge_profile_inputs(&load_profile_inputs(args)?).0)
}

fn print_result(label: &str, result: &autocomp_core::CompileResult) {
    println!("{label} {}", result.products.iter().map(|p| p.display().to_string()).collect::<Vec<_>>().join(", "));
    for decision in &result.decisions {
        println!("  [decision] {decision}");
    }
}

fn compile(args: &[String]) -> Result<(), String> {
    let source = source_from(args).ok_or("missing source file")?;
    let profile = load_profiles(args)?;
    let mut options = CompileOptions {
        optimization_level: args.iter().position(|a| a == "-O3").map(|_| 3).unwrap_or(0),
        instrument: args.iter().any(|a| a == "--instrument"),
        pgo_profile: option_value(args, "--pgo=").map(PathBuf::from),
    };
    if options.instrument {
        options.pgo_profile = None;
    }
    let mut compiler = AutoCompiler::default();
    let result = match profile.as_ref() {
        Some(profile) if !options.instrument => compiler.compile_with_pgo(&source, profile, &options)?,
        _ => compiler.compile(&source, &options)?,
    };
    print_result("compiled", &result);
    if args.iter().any(|a| a == "--baseline") {
        let baseline = compiler.compile(&source, &CompileOptions::default())?;
        print_result("baseline", &baseline);
        println!("  [summary] decisions {} -> {}, products {} -> {}",
            baseline.decisions.len(), result.decisions.len(),
            baseline.products.len(), result.products.len());
    }
    Ok(())
}

fn auto_pgo(args: &[String]) -> Result<(), String> {
    let source = source_from(args).ok_or("missing source file")?;
    let workload_text = option_value(args, "--workload=").unwrap_or_else(|| "default workload".into());
    let workload = Workload {
        argv: workload_text.split_whitespace().map(str::to_string).collect(),
        stdin: None,
        timeout: Duration::from_secs(60),
    };
    let mut compiler = AutoCompiler::default();
    let options = CompileOptions {
        optimization_level: args.iter().position(|a| a == "-O3").map(|_| 3).unwrap_or(0),
        ..CompileOptions::default()
    };
    let instrument_options = CompileOptions { instrument: true, ..options.clone() };
    let instrumented = compiler.compile(&source, &instrument_options)?;
    print_result("instrumented", &instrumented);
    let collected = autocomp_core::WorkloadProfile::from_workload(&workload, &instrumented)?;
    let profile_path = option_value(args, "--output=").map(PathBuf::from)
        .unwrap_or_else(|| source.with_extension("autoprof.txt"));
    fs::write(&profile_path, collected.render(ProfileFormat::Text)?).map_err(|e| e.to_string())?;
    println!("profile written to {} ({} workload samples / {} profile samples)", profile_path.display(), collected.sample_count, collected.sample_total());
    println!("  [coverage] branches={} {} loops={} {}",
        collected.branches.len(), collected.branches.join(", "),
        collected.loops.len(), collected.loops.join(", "));
    let result = compiler.compile_with_pgo(&source, &collected.profile, &options)?;
    print_result("auto-pgo", &result);
    println!("  [profile] workload={} total={} functions={} branches={} loops={}",
        collected.sample_count, collected.sample_total(), collected.profile.function_counts.len(),
        collected.profile.branch_counts.len(), collected.profile.loop_counts.len());
    println!("  [summary] instrumented decisions {} -> optimized decisions {}", instrumented.decisions.len(), result.decisions.len());
    if !args.iter().any(|a| a == "--no-run") {
        if let Some(program) = instrumented.products.iter().find(|p| p.extension().and_then(|e| e.to_str()) == Some("bin")) {
            run_workload(program, &workload)?;
        }
    }
    Ok(())
}

fn profile(args: &[String]) -> Result<(), String> {
    let source = source_from(args).ok_or("missing source file")?;
    let output = option_value(args, "--output=").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("autoprof.txt"));
    let mut compiler = AutoCompiler::default();
    let instrumented = compiler.compile(&source, &CompileOptions { instrument: true, ..CompileOptions::default() })?;
    let workload = Workload { argv: vec![source.display().to_string()], stdin: None, timeout: Duration::from_secs(60) };
    let collected = autocomp_core::WorkloadProfile::from_workload(&workload, &instrumented)?;
    let text = collected.render(ProfileFormat::Text)?;
    fs::write(&output, &text).map_err(|e| e.to_string())?;
    println!("profile written to {} ({} samples)", output.display(), collected.sample_count);
    print!("{text}");
    Ok(())
}

fn verify(args: &[String]) -> Result<(), String> {
    let source = source_from(args).ok_or("missing source file")?;
    let output = option_value(args, "--output=").map(PathBuf::from)
        .unwrap_or_else(|| source.with_extension("verify.txt"));
    let workload_text = option_value(args, "--workload=").unwrap_or_else(|| "default verify workload".into());
    let workload = Workload {
        argv: workload_text.split_whitespace().map(str::to_string).collect(),
        stdin: None,
        timeout: Duration::from_secs(60),
    };
    let profile = load_profiles(args)?.unwrap_or_else(|| {
        let mut profile = Profile::default();
        profile.function_counts.insert(source.file_stem().and_then(|s| s.to_str()).unwrap_or("module").into(), 1);
        profile
    });
    let mut compiler = AutoCompiler::default();
    let report: VerifyReport = compiler.verify(&source, &workload, &profile, &output)?;
    for check in &report.checks {
        let status = if let Some(reason) = &check.skipped {
            format!("SKIP[{reason}]")
        } else if check.passed {
            "PASS".into()
        } else {
            "FAIL".into()
        };
        println!("[{status}] {}: {}", check.name, check.detail);
    }
    println!("verification written to {} ({} pass / {} skip / {} fail)",
        output.display(), report.passed_count(), report.skipped_count(),
        report.checks.len() - report.passed_count() - report.skipped_count());
    if (args.iter().any(|a| a == "--strict-verify") || args.iter().any(|a| a == "--strict-check"))
        && report.skipped_count() > 0 {
        return Err("verification contains skipped checks under strict mode".into());
    }
    if !report.all_passed() {
        return Err(format!("verification failed: {} check(s) did not pass", report.checks.len() - report.passed_count() - report.skipped_count()));
    }
    Ok(())
}

fn report(args: &[String]) -> Result<(), String> {
    let input = args.iter().find(|a| !a.starts_with('-')).ok_or("missing source file")?;
    let source = if input.ends_with(".o") {
        PathBuf::from(format!("{}.ac", input.trim_end_matches(".o")))
    } else {
        PathBuf::from(input)
    };
    let format = match option_value(args, "--format=").as_deref() {
        Some("json") => autocomp_core::report::ReportFormat::Json,
        Some("html") | None => autocomp_core::report::ReportFormat::Html,
        Some(other) => return Err(format!("unsupported report format: {other}")),
    };
    let default_ext = if format == autocomp_core::report::ReportFormat::Json { "report.json" } else { "report.html" };
    let output = option_value(args, "--output=").map(PathBuf::from).unwrap_or_else(|| source.with_extension(default_ext));
    let profile_inputs = load_profile_inputs(args)?;
    let (profile, merge_report) = merge_profile_inputs(&profile_inputs);
    let mut compiler = AutoCompiler::default();
    let options = CompileOptions {
        pgo_profile: option_value(args, "--pgo=").map(PathBuf::from),
        ..CompileOptions::default()
    };
    let result = match profile.as_ref() {
        Some(profile) => compiler.compile_with_pgo(&source, profile, &options)?,
        None => compiler.compile(&source, &options)?,
    };
    let baseline = if args.iter().any(|a| a == "--baseline") {
        Some(compiler.compile(&source, &CompileOptions::default())?)
    } else {
        None
    };
    let output = if format == autocomp_core::report::ReportFormat::Json && output.extension().and_then(|e| e.to_str()) == Some("html") {
        output.with_extension("json")
    } else {
        output
    };
    let verify = if args.iter().any(|a| a == "--verify") {
        let verify_path = option_value(args, "--verify-output=").map(PathBuf::from)
            .unwrap_or_else(|| source.with_extension("verify.txt"));
        let workload_text = option_value(args, "--workload=").unwrap_or_else(|| "default verify workload".into());
        let workload = Workload {
            argv: workload_text.split_whitespace().map(str::to_string).collect(),
            stdin: None,
            timeout: Duration::from_secs(60),
        };
        let verify_profile = profile.clone().unwrap_or_else(|| {
            let mut p = Profile::default();
            p.function_counts.insert(source.file_stem().and_then(|s| s.to_str()).unwrap_or("module").into(), 1);
            p
        });
        Some(compiler.verify(&source, &workload, &verify_profile, &verify_path)?)
    } else {
        None
    };
    if let Some(report) = &merge_report {
        println!("profile merge: {} inputs / {} samples / {} overlaps",
            profile_inputs.len(), report.sample_count(), report.overlap_count());
    }
    let text = autocomp_core::report::render(&format!("AUTOCOMP Report · {}", source.display()), &result, profile.as_ref(), baseline.as_ref(), verify.as_ref(), merge_report.as_ref(), format);
    fs::write(&output, text).map_err(|e| e.to_string())?;
    println!("report written to {}", output.display());
    Ok(())
}

fn run_workload(program: &std::path::Path, workload: &Workload) -> Result<(), String> {
    let mut command = Command::new(program);
    command.args(&workload.argv[1..]);
    if workload.stdin.is_some() {
        command.stdin(Stdio::null());
    }
    let output = command.output().map_err(|e| format!("cannot run {}: {e}", program.display()))?;
    std::io::stdout().write_all(&output.stdout).map_err(|e| e.to_string())?;
    std::io::stderr().write_all(&output.stderr).map_err(|e| e.to_string())?;
    if !output.status.success() {
        return Err(format!("workload exited with {}", output.status));
    }
    Ok(())
}

fn bench(args: &[String]) -> Result<(), String> {
    let source = source_from(args).ok_or("missing source file")?;
    let start = std::time::Instant::now();
    let mut compiler = AutoCompiler::default();
    let result = compiler.compile(&source, &CompileOptions::default())?;
    println!("bench {}: {}ms, {} optimization decisions", source.display(), start.elapsed().as_millis(), result.decisions.len());
    Ok(())
}
